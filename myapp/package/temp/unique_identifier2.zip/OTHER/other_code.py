class number:
 def __init__(self, name="default name_x"):
  self.name = name
  self.age = 98
 